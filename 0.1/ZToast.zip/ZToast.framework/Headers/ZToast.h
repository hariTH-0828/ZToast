//
//  ZToast.h
//  ZToast
//
//  Created by Hariharan R S on 07/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for ZToast.
FOUNDATION_EXPORT double ZToastVersionNumber;

//! Project version string for ZToast.
FOUNDATION_EXPORT const unsigned char ZToastVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZToast/PublicHeader.h>


